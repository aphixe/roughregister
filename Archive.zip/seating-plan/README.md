Seating Plan Generator
----------------------

Created for Vidyamandir Classes
