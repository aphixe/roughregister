module.exports = {
	animate: {
	    flipLeft: [100],
	    flipRight: [100],
	    wave: [6000],
	    doublePhiThetaMixed: [8000]
	},
	up: [0.2],
	down: [0.2],
	left: [0.2],
	right: [0.2],
	front: [0.2],
	back: [0.2]
};