ROUGH REGISTER
==============

Just a rough-sketch collection of little node apps.

Made with `apper` (npm).
